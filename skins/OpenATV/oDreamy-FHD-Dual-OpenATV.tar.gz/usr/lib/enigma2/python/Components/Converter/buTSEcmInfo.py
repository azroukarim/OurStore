# Decompiled with PyLingual (https://pylingual.io)
# Internal filename: /home/raed/build_image/DM920/openpli-dreambox-oe-core/build/tmp/work/dm920-oe-linux-gnueabi/tspanel/10.8/tspanel/usr/lib/enigma2/python/Components/Converter/TSEcmInfo.py
# Bytecode version: 3.13.0rc3 (3571)
# Source timestamp: 2001-10-27 20:43:45 UTC (1004215425)

from enigma import iServiceInformation, iPlayableService
from os import popen as os_popen
from Components.Converter.Converter import Converter
from Components.Element import cached
from Tools.Directories import fileExists
from Components.Converter.Poll import Poll

class buTSEcmInfo(Poll, Converter, object):

    def __init__(self, type):
        Poll.__init__(self)
        Converter.__init__(self, type)
        self.poll_interval = 2000
        self.poll_enabled = True

    @cached
    def getText(self):
        ecminfo = 'No ECM Info.'
        if self.source.service and self.source.service.info() and fileExists('/tmp/ecm.info'):
            cmd = 'cat /tmp/ecm.info'
            ecminfo = self.getCmdOutput(cmd)
        return ecminfo
    text = property(getText)

    def changed(self, what):
        if what[0] == self.CHANGED_SPECIFIC and what[1] == iPlayableService.evUpdatedInfo or what[0] == self.CHANGED_POLL:
            Converter.changed(self, what)

    def getCmdOutput(self, cmd):
        pipe = os_popen('{ ' + cmd + '; } 2>&1', 'r')
        text = pipe.read()
        pipe.close()
        if text[-1:] == '\n':
            text = text[:-1]
        return text